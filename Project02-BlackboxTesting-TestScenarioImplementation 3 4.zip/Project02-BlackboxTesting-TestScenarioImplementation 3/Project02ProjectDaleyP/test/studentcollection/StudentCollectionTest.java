package studentcollection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import static org.junit.Assert.*;

import student.Student;
import studentspec.StudentSpec;

import studentcollection.StudentCollectionSpec.StudentCollectionException;

/**
 *
 * @author joe
 */
public class StudentCollectionTest {

    public StudentCollectionTest() {
    }

    public void createStudentCollectionTest() {
        StudentSpec result;
        StudentCollectionSpec.StudentCollectionException thrownException;
        try {
            thrownException = null;
            StudentCollectionSpec collection = StudentCollection.createStudentCollection(-1);
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            thrownException = anException;

        }
        assertNotNull(thrownException);
        try {
            thrownException = null;
            StudentCollectionSpec collection1 = StudentCollection.createStudentCollection(0);
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            thrownException = anException;

        }
        assertNotNull(thrownException);
        try {
            thrownException = null;

            StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(1);
            assertEquals(collection2.isFull(), false);
            assertEquals(collection2.isEmpty(), false);
            assertEquals(collection2.getSpacesRemaining(), 1);
            assertEquals(collection2.getStudentCount(), 0);
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            thrownException = anException;

        }
        assertNull(thrownException);

    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of getCapacity method, of class StudentCollection.
     */
    @Test
    public void testGetCapacity() {
        System.out.println("getCapacity");
        // case 1
        StudentCollectionSpec collection = StudentCollection.createStudentCollection();
        assertEquals(5000, collection.getCapacity());
        // TODO review the generated test code and remove the default call to fail.
        //case 2 
        StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(5);
        assertEquals(5, collection2.getCapacity());

    }

    /**
     * Test of reset method, of class StudentCollection.
     */
    @Test
    public void testReset() {
        System.out.println("reset");
        StudentCollectionSpec instance = StudentCollection.createStudentCollection();
        instance.reset();
        // TODO review the generated test code and remove the default call to fail.

        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        collection.addStudent(student);
        collection.addStudent(student2);
        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(2, collection.getStudentCount());
        collection.reset();
        assertEquals(true, collection.isEmpty());
        assertEquals(0, collection.getStudentCount());

    }

    /**
     * Test of isFull method, of class StudentCollection.
     */
    @Test
    public void testIsFull() {
        System.out.println("isFull");

        // TODO review the generated test code and remove the default call to fail.
        //case 1
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        assertEquals(true, collection.isEmpty());
        assertEquals(false, collection.isFull());

        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("2345678", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("3456789", "Daley", "Christine", "Lee", "Bus", 14, 15);
        StudentSpec student5 = Student.create("4567891", "Daley", "Matt", "jack", "csc", 18, 17);
        StudentSpec student6 = Student.create("5678912", "daley", "Fail", "tst", "csc", 16, 17);
        StudentSpec results;

        StudentCollectionSpec.StudentCollectionException thrownException = null;
//case 2
        try {
            collection.addStudent(student);
            results = student;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            results = null;
            thrownException = anException;
        }
        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());

        assertEquals(5, collection.getCapacity());

        assertEquals(4, collection.getSpacesRemaining());

// case 3
        try {
            collection.addStudent(student);
            collection.addStudent(student2);
            collection.addStudent(student3);
            collection.addStudent(student4);
            collection.addStudent(student5);

        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            results = null;
            thrownException = anException;
        }
        assertEquals(false, collection.isEmpty());
        assertEquals(true, collection.isFull());

        assertEquals(5, collection.getCapacity());

        assertEquals(0, collection.getSpacesRemaining());

        //case 4 
        try {
            collection.addStudent(student);
            collection.addStudent(student2);
            collection.addStudent(student3);
            collection.addStudent(student4);
            collection.addStudent(student5);
            collection.addStudent(student6);
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            thrownException = anException;

        }
        assertNotNull(thrownException);
    }

    /**
     * Test of isEmpty method, of class StudentCollection.
     */
    @Test
    public void testIsEmpty() {

        // TODO review the generated test code and remove the default call to fail.
        //case 1
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        assertEquals(true, collection.isEmpty());
        assertEquals(false, collection.isFull());

        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);

        StudentSpec results;

//case 2
        collection.addStudent(student);
        results = student;

        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());

        assertEquals(5, collection.getCapacity());
        assertEquals(results.getSID(), student.getSID());

        assertEquals(4, collection.getSpacesRemaining());
    }

    /**
     * Test of getStudentCount method, of class StudentCollection.
     */
    @Test
    public void testGetStudentCount() {
        System.out.println("getStudentCount");

        // TODO review the generated test code and remove the default call to fail.
//case1 
        StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(5);
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("2345678", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("3456789", "Daley", "Christine", "Lee", "Bus", 14, 15);
        StudentSpec student5 = Student.create("4567891", "Daley", "Matt", "jack", "csc", 18, 17);
        StudentSpec student6 = Student.create("5678912", "daley", "Fail", "tst", "csc", 16, 17);
        StudentSpec results;
        assertEquals(true, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(0, collection.getStudentCount());
        assertEquals(5, collection.getCapacity());
        StudentCollectionSpec.StudentCollectionException thrownException;
        //case 2

        collection.addStudent(student);
        collection.addStudent(student2);
        collection.addStudent(student3);
        collection.addStudent(student4);
        collection.addStudent(student5);

        assertEquals(false, collection.isEmpty());
        assertEquals(true, collection.isFull());
        assertEquals(5, collection.getStudentCount());
        assertEquals(5, collection.getCapacity());

        assertEquals(0, collection.getSpacesRemaining());

    }

    /**
     * Test of addStudent method, of class StudentCollection.
     */
    @Test
    public void testAddStudent() {
        System.out.println("addStudent");

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(4);
        StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(3);
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("2345678", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("3456789", "Daley", "Christine", "Lee", "Bus", 14, 15);
        StudentSpec student5 = Student.create("4567891", "Fail", "Fail", "tst", "csc", 16, 17);
        StudentSpec result;

        StudentCollectionSpec.StudentCollectionException thrownException;

        try {
            thrownException = null;
            collection.addStudent(student);
            result = student;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNull(thrownException);
        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(3, collection.getSpacesRemaining());
        StudentSpec recStudent = collection.retrieveStudentBySID(student.getSID());
        assertNotNull(recStudent);
        assertEquals(student.getSID(), recStudent.getSID());

        try {
            thrownException = null;
            collection.addStudent(student2);
            result = student2;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNull(thrownException);
        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(2, collection.getSpacesRemaining());
        StudentSpec recStudent2 = collection.retrieveStudentBySID(student2.getSID());
        assertNotNull(recStudent2);
        assertEquals(student2.getSID(), recStudent2.getSID());
        try {
            thrownException = null;
            collection.addStudent(student3);
            result = student3;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNull(thrownException);
        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(1, collection.getSpacesRemaining());
        StudentSpec recStudent3 = collection.retrieveStudentBySID(student3.getSID());
        assertNotNull(recStudent3);
        assertEquals(student3.getSID(), recStudent3.getSID());

        try {
            thrownException = null;
            collection.addStudent(student4);
            result = student4;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNull(thrownException);
        assertEquals(false, collection.isEmpty());
        assertEquals(true, collection.isFull());
        assertEquals(0, collection.getSpacesRemaining());
        StudentSpec recStudent4 = collection.retrieveStudentBySID(student4.getSID());
        assertNotNull(recStudent4);
        assertEquals(student4.getSID(), recStudent4.getSID());

        try {
            thrownException = null;
            collection.addStudent(student5);
            result = student5;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNotNull(thrownException);
        assertEquals(false, collection.isEmpty());
        assertEquals(true, collection.isFull());
        assertEquals(0, collection.getSpacesRemaining());
        StudentSpec recStudent5 = collection.retrieveStudentBySID(student5.getSID());
        assertNull(recStudent5);

        //   assertNull(thrownException);
        try {
            thrownException = null;
            collection2.addStudent(student);
            result = student;
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNull(thrownException);
        assertEquals(false, collection2.isEmpty());
        assertEquals(false, collection2.isFull());
        assertEquals(2, collection2.getSpacesRemaining());
        StudentSpec recStudent1 = collection2.retrieveStudentBySID(student.getSID());
        assertNotNull(recStudent1);
        assertEquals(student.getSID(), recStudent1.getSID());

    }

    /**
     * Test of retrieveStudentBySID method, of class StudentCollection.
     */
    @Test
    public void testRetrieveStudentBySID() {
        System.out.println("retrieveStudentBySID");

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);

        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);

        //case 1
        collection.addStudent(student);
        String sid = "1234567";
        assertEquals(1, collection.getStudentCount());
        assertEquals(student, collection.retrieveStudentBySID(sid));

        // case 2
        StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(5);

        String randomsid = "6543217";

        collection2.addStudent(student);

        assertNull(collection2.retrieveStudentBySID(randomsid));
    }

    /**
     * Test of removeStudentBySID method, of class StudentCollection.
     */
    @Test
    public void testRemoveStudentBySID() {
        System.out.println("removeStudentBySID");
        StudentSpec results;
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        assertEquals(true, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(5, collection.getCapacity());
        assertEquals(0, collection.getStudentCount());
        assertEquals(5, collection.getSpacesRemaining());
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentCollectionSpec.StudentCollectionException thrownException;
        try {
            collection.addStudent(student);
            collection.addStudent(student2);
            assertEquals(false, collection.isEmpty());
            assertEquals(false, collection.isFull());
            assertEquals(5, collection.getCapacity());
            assertEquals(2, collection.getStudentCount());
            assertEquals(3, collection.getSpacesRemaining());

            collection.removeStudentBySID("1234567");
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            results = null;
            thrownException = anException;
        }
        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());

        assertEquals(5, collection.getCapacity());
        assertEquals(1, collection.getStudentCount());
        assertEquals(4, collection.getSpacesRemaining());
    }

    /**
     * Test of toString method, of class StudentCollection.
     */
    @Test
    public void testToString() {
        System.out.println("toString");

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(4);

        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec results;
        String returnedString = "";
       String returnedString2 = student + "&" + student2;
        StudentCollectionSpec.StudentCollectionException thrownException;

        try {
            StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(4);
            returnedString = "EmptyString";
            returnedString = collection2.toString();
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            results = null;
            thrownException = anException;
        }
    
        try {

            collection.addStudent(student);
            collection.addStudent(student2);

        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            results = null;
            thrownException = anException;
        }
        assertEquals(student + "&" + student2, collection.toString());
    }

    /**
     * Test of createIterator method, of class StudentCollection.
     */
    @Test
    public void testCreateIterator() {
        System.out.println("createIterator");

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec refCollection = StudentCollection.createStudentCollection(4);
        NoSuchElementException element;
        StudentCollectionSpec retrieveCollection = StudentCollection.createStudentCollection(10);

        StudentSpec student = Student.create("0000001", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("0000002", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("0000003", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("0000004", "Daley", "Christine", "Lee", "Bus", 14, 15);
        StudentCollectionSpec.StudentCollectionException thrownException;

        refCollection.addStudent(student);
        refCollection.addStudent(student2);
        refCollection.addStudent(student3);
        refCollection.addStudent(student4);

        Iterator<StudentSpec> iterator = null;
        ;
      StudentSpec [] checkCollection={student,student2,student3,student4};
        
        int count = 0;
        StudentSpec result;
        try {
            thrownException = null;
            iterator = refCollection.createIterator();
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNotNull(iterator);
        while (iterator.hasNext() == true) {
            StudentSpec s1 = iterator.next();
 for(int i=0;i<checkCollection.length;i++)
     if(checkCollection[i]!=null && s1.getSID()==checkCollection[i].getSID()){
       checkCollection[i]=null;
         ++count;
     }

        
    int check=0;
        for(int i=0;i<checkCollection.length;i++){
            if(checkCollection[i]!=null){count++;}
        }
          
            
        }

        try {
            iterator.next();
            element = null;
        } catch (NoSuchElementException e) {
            element = e;
        }
        assertNotNull(element);
      
  
        assertFalse(iterator.hasNext());
//    
          try {
                  StudentCollectionSpec collection = StudentCollection.createStudentCollection(4);
            element = null;
        } catch (NoSuchElementException e) {
            element = e;
        }
       assertNotNull(element);
                assertFalse(iterator.hasNext());
        UnsupportedOperationException element2;
        try {
            StudentCollectionSpec collection2 = StudentCollection.createStudentCollection(5);
            element2 = null;
        } catch (UnsupportedOperationException e) {
            element2 = e;
        }
        assertNotNull(element2);

        try {
            StudentCollectionSpec collection3 = StudentCollection.createStudentCollection(5);
            element2 = null;
            collection3.addStudent(student);
            collection3.addStudent(student2);
            collection3.addStudent(student3);
        } catch (UnsupportedOperationException e) {
            element2 = e;
        }
        assertNotNull(element2);
    }

    /**
     * Test of getSpacesRemaining method, of class StudentCollection.
     */
    @Test
    public void testGetSpacesRemaining() {
        System.out.println("getSpacesRemaining");

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("2345678", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("3456789", "Daley", "Christine", "Lee", "Bus", 14, 15);
        StudentSpec student5 = Student.create("4567891", "Daley", "Matt", "jack", "csc", 18, 17);

        StudentSpec results;

        assertEquals(true, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(5, collection.getCapacity());
        assertEquals(5, collection.getSpacesRemaining());

        StudentCollectionSpec.StudentCollectionException thrownException;

        collection.addStudent(student);
        results = student;

        assertEquals(false, collection.isEmpty());
        assertEquals(false, collection.isFull());
        assertEquals(5, collection.getCapacity());
        assertEquals(4, collection.getSpacesRemaining());

        collection.addStudent(student2);
        collection.addStudent(student3);
        collection.addStudent(student4);
        collection.addStudent(student5);

        assertEquals(false, collection.isEmpty());
        assertEquals(true, collection.isFull());
        assertEquals(5, collection.getCapacity());
        assertEquals(0, collection.getSpacesRemaining());

    }

    /**
     * Test of writeCollectionToDisk method, of class StudentCollection.
     */
    @Test
    public void testWriteCollectionToDisk() {
        System.out.println("writeCollectionToDisk");
        StudentCollectionSpec retrieveCollection = StudentCollection.createStudentCollection(10);

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        StudentCollectionSpec.StudentCollectionException thrownException;

        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("2345678", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("3456789", "Daley", "Christine", "Lee", "Bus", 14, 15);
        IllegalArgumentException throwException;
        //case1
        try {
            throwException = null;
            collection.writeCollectionToDisk(null);
        } catch (IllegalArgumentException e) {
            throwException = e;

        }
        assertNotNull(throwException);

        //case 2
        try {
            throwException = null;
            collection.writeCollectionToDisk("");
        } catch (IllegalArgumentException e) {
            throwException = e;

        }
        assertNotNull(throwException);

        collection.addStudent(student);
        collection.addStudent(student2);

        StudentSpec[] arraylist = {student, student2, student3, student4};
        try {
            throwException = null;
            collection.writeCollectionToDisk("Valid");
        } catch (IllegalArgumentException e) {
            throwException = e;

        }
        assertNull(throwException);
        assertEquals(true, StudentCollectionSpec.fileExists("Valid"));

        try {
            throwException = null;
            collection.retrieveCollectionFromDisk("Valid");
        } catch (IllegalArgumentException e) {
            throwException = e;

        }
        assertNull(throwException);
        Iterator<StudentSpec> iterator = null;

       StudentSpec [] checkCollection={student,student2,student3,student4};
        
        int count = 0;
        StudentSpec result;
        try {
            thrownException = null;
            iterator = retrieveCollection.createIterator();
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNotNull(iterator);
        while (iterator.hasNext() == true) {
            StudentSpec s1 = iterator.next();
 for(int i=0;i<checkCollection.length;i++)
     if(checkCollection[i]!=null && s1.getSID()==checkCollection[i].getSID()){
       checkCollection[i]=null;
         ++count;
     }

        
    int check=0;
        for(int i=0;i<checkCollection.length;i++){
            if(checkCollection[i]!=null){count++;}
        }
          
        NoSuchElementException element;
        try {
            iterator.hasNext();
            element = null;
        } catch (NoSuchElementException e) {
            element = e;
        }
        assertNull(element);
        assertTrue(collection.getStudentCount() ==retrieveCollection.getStudentCount());
        assertTrue(count == retrieveCollection.getStudentCount());
     //   assertEquals(checkCollection.isEmpty(), true);
        
              assertEquals(check,0); 
    }

    

    
    }
    public void testFileExists() {
        System.out.println("fileExists");

        // TODO review the generated test code and remove the default call to fail.
//case 1
        IllegalArgumentException thrownException = null;
        try {
            StudentCollectionSpec.fileExists(null);
        } catch (IllegalArgumentException e) {
            thrownException = e;
        }
        assertNotNull(thrownException);
        //case2  
        String temp = "";
        thrownException = null;
        try {
            StudentCollectionSpec.fileExists(temp);
        } catch (IllegalArgumentException e) {
            thrownException = e;
        }
        //  assertNotNull(thrownException);

        StudentCollectionSpec collection = StudentCollection.createStudentCollection(2);
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);

        collection.addStudent(student);
        collection.addStudent(student2);

        collection.writeCollectionToDisk("Knownname");
        assertTrue(StudentCollectionSpec.fileExists("Knownname"));

    }

    /**
     * Test of retrieveCollectionFromDisk method, of class StudentCollection.
     */
    @Test
    public void testRetrieveCollectionFromDisk() {
        System.out.println("retrieveCollectionFromDisk");

        // TODO review the generated test code and remove the default call to fail.
        StudentCollectionSpec collection = StudentCollection.createStudentCollection(5);
        StudentCollectionSpec checkcollection = StudentCollection.createStudentCollection(5);
        StudentCollectionSpec retrieveCollection = StudentCollection.createStudentCollection(10);
        StudentSpec student = Student.create("1234567", "Daley", "Pat", "John", "csc", 10, 11);
        StudentSpec student2 = Student.create("7654321", "foster", "sarah", "none", "csc", 11, 10);
        StudentSpec student3 = Student.create("2345678", "Daley", "Kyle", "Joe", "Bus", 12, 13);
        StudentSpec student4 = Student.create("3456789", "Daley", "Christine", "Lee", "Bus", 14, 15);

        StudentCollectionSpec.StudentCollectionException thrownException;
        IllegalArgumentException throwException;
        //case1
        try {
            throwException = null;
            collection.retrieveCollectionFromDisk(null);
        } catch (IllegalArgumentException e) {
            throwException = e;

        }
        assertNotNull(throwException);

        //case 2
        try {
            throwException = null;
            collection.retrieveCollectionFromDisk("");
        } catch (IllegalArgumentException e) {
            throwException = e;

        }
        assertNotNull(throwException);
        //case 3
        String temp = "unknown";
        try {
            thrownException = null;
            collection.retrieveCollectionFromDisk(temp);
        } catch (StudentCollectionSpec.StudentCollectionException anException) {
            thrownException = anException;
        }
        assertNotNull(thrownException);

        // case4
        String filename = "nonserializable";
        try {
            thrownException = null;
            collection.retrieveCollectionFromDisk(filename);
            collection.retrieveCollectionFromDisk(temp);
        } catch (StudentCollectionSpec.StudentCollectionException anException) {
            thrownException = anException;
        }
        assertNotNull(thrownException);

        //case 5 
        try {
            collection.addStudent(student);
            collection.addStudent(student2);

            checkcollection.addStudent(student);
            checkcollection.addStudent(student2);

            thrownException = null;
            collection.writeCollectionToDisk("File");

        } catch (StudentCollectionSpec.StudentCollectionException anException) {
            thrownException = anException;
        }
        assertNull(thrownException);
        assertTrue(StudentCollectionSpec.fileExists("File"));
        try {
            thrownException = null;
            collection.retrieveCollectionFromDisk("File");

        } catch (StudentCollectionSpec.StudentCollectionException anException) {
            thrownException = anException;
        }
        assertNull(thrownException);
        assertEquals(collection.getStudentCount(), collection.getStudentCount());
        assertEquals(2, checkcollection.getStudentCount());

        Iterator<StudentSpec> iterator = null;

       StudentSpec [] checkCollection={student,student2,student3,student4};
        
        int count = 0;
        StudentSpec result;
        try {
            thrownException = null;
            iterator = retrieveCollection.createIterator();
        } catch (StudentCollectionSpec.StudentCollectionException anException) {

            result = null;
            thrownException = anException;
        }
        assertNotNull(iterator);
        while (iterator.hasNext() == true) {
            StudentSpec s1 = iterator.next();
 for(int i=0;i<checkCollection.length;i++)
     if(checkCollection[i]!=null && s1.getSID()==checkCollection[i].getSID()){
       checkCollection[i]=null;
         ++count;
     }

        
    int check=0;
        for(int i=0;i<checkCollection.length;i++){
            if(checkCollection[i]!=null){count++;}
        }
          
        NoSuchElementException element;
        try {
            iterator.hasNext();
            element = null;
        } catch (NoSuchElementException e) {
            element = e;
        }
        assertNull(element);
        assertTrue(collection.getStudentCount() ==retrieveCollection.getStudentCount());
        assertTrue(count == retrieveCollection.getStudentCount());
     //   assertEquals(checkCollection.isEmpty(), true);
         assertEquals(check,0); 
    }

    }}
